SPATIAL DATA LAB - PRACTICE FILES
Empirical Development Economics, guest lecture, FEB UI

WHAT THIS IS
These files are SYNTHETIC. They were generated for this class so that the
patterns are easy to see. Every district and village name in them is invented.
Nothing here describes a real place, and no result from these files should be
reported anywhere.

VECTOR LAYERS
  kabupaten.gpkg          12 district polygons, with a poverty column and others
  kabupaten_polos.gpkg    the same polygons with no attributes, for the join exercise
  desa.gpkg               900 village points
  jalan.gpkg              4 main road lines

RASTER LAYERS
  nightlights.asc (+ .prj)  night lights, 250 x 200 cells of 0.02 degrees
  elevasi.asc (+ .prj)      elevation on the same grid

TABLES
  statistik_kabupaten.csv   district statistics, keyed on the column "kode"
  podes_sample.csv          village facility counts, keyed on "iddesa"
  desa_analisis_contoh.csv  a worked example table
  village_coordinates.csv   900 villages with X (longitude) and Y (latitude),
                            for the Add Delimited Text Layer exercise

WHICH FILE FOR WHICH EXERCISE
  1  open a layer, check its CRS        kabupaten.gpkg
  2  join a statistics table            kabupaten_polos.gpkg + statistik_kabupaten.csv
  3  thematic map                       kabupaten.gpkg
  4  point layer from a CSV             village_coordinates.csv
  5  buffer and spatial join            desa.gpkg + jalan.gpkg
  6  zonal statistics                   nightlights.asc + kabupaten.gpkg
  7  print layout                       whatever you made in exercise 3

COORDINATE SYSTEM
  Everything is in EPSG:4326 (degrees). Reproject to EPSG:32749 (UTM 49S)
  before measuring any distance or area.

WHERE THE REAL VERSIONS COME FROM
  boundaries and statistics   BPS
  official base maps          Badan Informasi Geospasial, tanahair.indonesia.go.id
  roads                       OpenStreetMap
  night lights                VIIRS
  rainfall                    CHIRPS
