SPATIAL DATA LAB - PRACTICE FILES
Empirical Development Economics, guest lecture, FEB UI

WHAT THIS IS
These files are SYNTHETIC. They were generated for this class so that the
patterns are easy to see. Every district and village name in them is invented.
Nothing here describes a real place, and no result from these files should be
reported anywhere.

VECTOR LAYERS
  kabupaten.gpkg          12 district polygons, with a poverty column and others
  kabupaten_polos.gpkg    the same polygons with no attributes, for the join exercise
  desa.gpkg               900 village points
  jalan.gpkg              4 main road lines

RASTER LAYERS
  nightlights.asc (+ .prj)  night lights, 250 x 200 cells of 0.02 degrees
  elevasi.asc (+ .prj)      elevation on the same grid

TABLES
  statistik_kabupaten.csv   district statistics, keyed on the column "kode"
  podes_sample.csv          village facility counts, keyed on "iddesa"
  desa_analisis_contoh.csv  a worked example table
  village_coordinates.csv   900 villages with X (longitude) and Y (latitude),
                            for the Add Delimited Text Layer exercise

WHICH FILE FOR WHICH EXERCISE
  1  open a layer, check its CRS        kabupaten.gpkg
  2  join a statistics table            kabupaten_polos.gpkg + statistik_kabupaten.csv
  3  thematic map                       kabupaten.gpkg
  4  point layer from a CSV  (*)       village_coordinates.csv
  5  buffer and spatial join            desa.gpkg + jalan.gpkg
  6  zonal statistics                   nightlights.asc + kabupaten.gpkg
  7  print layout            (*)        whatever you made in exercise 3

  (*) We do not run these two together in the session. The steps are on the
      slides, and everything you need is in this bundle, so do them yourself.

TWO THINGS THAT WILL CATCH YOU
  Exercise 2. The key is "kode_kab" on the map but "kode" in the CSV, and the
  map holds it as text. If you leave "Detect field types" ticked when you load
  the CSV, QGIS reads "kode" as a number, the join returns twelve empty cells,
  and nothing warns you. Untick it, or fix the type with the Field Calculator.

  Exercise 5. Reproject before you buffer. 147 of the 900 villages lie within
  5 km of a road; you can check your answer against the column
  "jarak_jalan_km_TRUE" in desa.gpkg, which holds the real distance.

IF YOU WANT MORE
  elevasi.asc        run exercise 6 again on a second raster
  podes_sample.csv   joins to desa.gpkg on "iddesa", but 25 of its 888 codes
                     do not match. That is the partial join we talk about:
                     count your rows before and after.

COORDINATE SYSTEM
  Everything is in EPSG:4326 (degrees). Reproject to EPSG:32749 (UTM 49S)
  before measuring any distance or area.

WHERE THE REAL VERSIONS COME FROM
  boundaries and statistics   BPS
  official base maps          Badan Informasi Geospasial, tanahair.indonesia.go.id
  roads                       OpenStreetMap
  night lights                VIIRS
  rainfall                    CHIRPS
